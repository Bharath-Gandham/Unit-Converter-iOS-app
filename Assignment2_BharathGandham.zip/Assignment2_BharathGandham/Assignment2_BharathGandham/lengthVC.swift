//
//  lengthVC.swift
//  Assignment2_BharathGandham
//
//  Created by Bharath Gandham on 10/16/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit
var lengthList=["Kilometers to Miles","Miles to Kilometers","Yard to Feet","Feet to Yard","Inches to Centimeters","Centimeters to Inches"]
var myIndex=10
var variableForChecking=0
class lengthVC: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lengthList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "lengthCellForReuse")
        cell?.textLabel?.text=lengthList[indexPath.row]
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex=indexPath.row
        variableForChecking=1
        performSegue(withIdentifier: "length2Output", sender: self)
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section:Int) -> String?
    {
        return "Length Conversions"
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    /* In a storyboard-based application, you will often want to do a little preparation before navigation*/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
}
}

