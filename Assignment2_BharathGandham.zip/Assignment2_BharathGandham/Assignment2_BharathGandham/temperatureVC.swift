//
//  temperatureVC.swift
//  Assignment2_BharathGandham
//
//  Created by Bharath Gandham on 10/16/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit
var temperatureList=["Fahrenheit to Celsius","Celsius to Fahrenheit"]
class temperatureVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return temperatureList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "temperatureCellForReuse")
        cell?.textLabel?.text=temperatureList[indexPath.row]
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex=indexPath.row
        variableForChecking=4
        performSegue(withIdentifier: "temperature2Output", sender: self)
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section:Int) -> String?
    {
        return "Temperature Conversions"
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
