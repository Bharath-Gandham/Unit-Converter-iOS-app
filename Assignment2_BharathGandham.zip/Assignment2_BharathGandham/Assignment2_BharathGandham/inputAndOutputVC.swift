//
//  inputAndOutputVC.swift
//  Assignment2_BharathGandham
//
//  Created by Bharath Gandham on 10/16/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit
/*protocol inputOutputVCDelegate : NSObjectProtocol{
    func doSomethingWith(data: String)
}
*/
class inputAndOutputVC: UIViewController,UITextFieldDelegate {
    var input=""
    @IBOutlet weak var lblForTabelCellName: UILabel!
    var floatOutput:Double=0.00
    @IBOutlet weak var lblToThrowErrrorMessages: UILabel!
    @IBOutlet var lblToThrowErrors: UIView!
    @IBOutlet weak var lblOutput: UILabel!
    @IBOutlet weak var txtInput: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        txtInput.becomeFirstResponder()
        if variableForChecking==1{
            lblForTabelCellName.text=lengthList[myIndex]
        }
        if variableForChecking==2{
            lblForTabelCellName.text=liquidlist[myIndex]
        }
        if variableForChecking==3{
            lblForTabelCellName.text=massList[myIndex]
        }
        if variableForChecking==4{
            lblForTabelCellName.text=temperatureList[myIndex]
        }
    // Do any additional setup after loading the view.
    }
    
    @IBAction func btnToConvert(_ sender: Any) {
        lblToThrowErrrorMessages.text=nil
        
        input=txtInput.text!
        if input==""{
            lblToThrowErrrorMessages.text="*Empty Input"
            lblOutput.text="Output"
        }
            else{
            let floatInput=Double(input)
            //print(floatInput!)
            if let floatInputUnWrapped=floatInput{
        if variableForChecking==1{
            
        switch myIndex{
        case 0:
            floatOutput=floatInputUnWrapped*0.621371
            lblOutput.text="Miles:"+String(floatOutput)
        case 1:
            floatOutput=floatInputUnWrapped*1.60934
            lblOutput.text="Kilometers:"+String(floatOutput)
        case 2:
            floatOutput=floatInputUnWrapped*3
            lblOutput.text="Feet:"+String(floatOutput)
        case 3:
            floatOutput=floatInputUnWrapped*0.33333
            lblOutput.text="Yard:"+String(floatOutput)
        case 4:
            floatOutput=floatInputUnWrapped*2.54
            lblOutput.text="Centimeters:"+String(floatOutput)
        case 5:
            floatOutput=(floatInputUnWrapped*0.3937)
            //print(floatOutput)
            lblOutput.text="Inches:"+String(floatOutput)
        default:
            lblToThrowErrrorMessages.text="Invalid Selection of table Cell"
            }
            }
                if variableForChecking==2{
                    switch myIndex{
                    case 0:
                        floatOutput=floatInputUnWrapped*0.264172
                        lblOutput.text="Gallons:"+String(floatOutput)
                    case 1:
                        floatOutput=floatInputUnWrapped*3.78541
                        lblOutput.text="Liters:"+String(floatOutput)
                    case 2:
                        floatOutput=floatInputUnWrapped*0.125
                        lblOutput.text="Gallons:"+String(floatOutput)
                    case 3:
                        floatOutput=floatInputUnWrapped*9.60762
                        lblOutput.text="Pints:"+String(floatOutput)
                    case 4:
                        floatOutput=floatInputUnWrapped*0.20817
                        lblOutput.text="Gallons:"+String(floatOutput)
                    case 5:
                        floatOutput=floatInputUnWrapped*4.80381
                        lblOutput.text="Quarts:"+String(floatOutput)
                        
                    default:
                        lblToThrowErrrorMessages.text="Invalid selection of table cell"
                    }
                }
                if variableForChecking==3{
                    switch myIndex {
                    case 0:
                        floatOutput=floatInputUnWrapped*2.20462
                        lblOutput.text="Pounds:"+String(floatOutput)
                    case 1:
                        floatOutput=floatInputUnWrapped*0.453592
                        lblOutput.text="Kilograms:"+String(floatOutput)
                    case 2:
                        floatOutput=floatInputUnWrapped*28.3495
                        lblOutput.text="Grams:"+String(floatOutput)
                    case 3:
                        floatOutput=floatInputUnWrapped*0.035274
                        lblOutput.text="Ounce:"+String(floatOutput)
                    default:
                        lblToThrowErrrorMessages.text="Invalid selection of table cell"
                    }
                }
                if variableForChecking==4{
                    switch myIndex {
                    case 0:
                        floatOutput=(floatInputUnWrapped-32)*0.5555
                        lblOutput.text="Celsius:"+String(floatOutput)
                    case 1:
                        floatOutput=(floatInputUnWrapped*1.8)+32
                        lblOutput.text="Fahrenheit:"+String(floatOutput)
                    default:
                        lblToThrowErrrorMessages.text="Invalid selectiin of table cell"
                    }
                }
        }
        
    }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        txtInput.resignFirstResponder()
        return true
    }
    
    @IBAction func btnRefresh(_ sender: Any) {
        txtInput.text=nil
        lblToThrowErrrorMessages.text=nil
        lblOutput.text="Output"
    }
    /* weak var delegate : inputOutputVCDelegate?*/

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
